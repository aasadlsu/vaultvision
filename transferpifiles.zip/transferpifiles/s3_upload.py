import boto3
import os

# PLACEHOLDER CONFIG - update later if needed
AWS_ACCESS_KEY = "your-access-key-id"
AWS_SECRET_KEY = "your-secret-access-key"
S3_BUCKET_NAME = "your-s3-bucket-name"
S3_REGION = "us-east-1"

def upload_to_s3(file_path):
    filename = os.path.basename(file_path)
    session = boto3.session.Session(
        aws_access_key_id=AWS_ACCESS_KEY,
        aws_secret_access_key=AWS_SECRET_KEY,
        region_name=S3_REGION
    )
    s3 = session.resource("s3")
    bucket = s3.Bucket(S3_BUCKET_NAME)

    with open(file_path, "rb") as data:
        bucket.put_object(Key=filename, Body=data)

    print(f" Uploaded {filename} to S3 bucket '{S3_BUCKET_NAME}'")

