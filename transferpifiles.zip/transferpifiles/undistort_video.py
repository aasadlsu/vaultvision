import cv2
import numpy as np
import os
import time
import threading

# ====== CONFIGURATION ======
INPUT_VIDEO_PATH = "test_videos/GX010005.MP4"  # Adjust if needed
OUTPUT_VIDEO_PATH = "test_videos/undistorted_output.mp4"

# ====== CAMERA PARAMETERS FROM GYROFLOW ======
K = np.array([[1540.903328465489, 0, 1929.684494578750],
              [0, 1543.025891929817, 1053.082085218762],
              [0, 0, 1]], dtype=np.float32)

D = np.array([0.0417990835958765,
              0.0005121408585081,
              0.0081199812345142,
              -0.0078717430553169], dtype=np.float32)

# ====== CHECK IF VIDEO EXISTS ======
if not os.path.exists(INPUT_VIDEO_PATH):
    print(f"ERROR: Video file not found at {INPUT_VIDEO_PATH}")
    exit()

# ====== OPEN VIDEO ======
cap = cv2.VideoCapture(INPUT_VIDEO_PATH)
if not cap.isOpened():
    print("ERROR: Unable to open video file.")
    exit()

# Get video properties
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
frame_interval = 1.0 / fps  # Exact time per frame in seconds

# **Precompute undistortion maps**
new_K = cv2.fisheye.estimateNewCameraMatrixForUndistortRectify(
    K, D, (frame_width, frame_height), np.eye(3), balance=0.5
)
map1, map2 = cv2.fisheye.initUndistortRectifyMap(
    K, D, np.eye(3), new_K, (frame_width, frame_height), cv2.CV_16SC2
)

print("🔄 Processing video...")

# ===== ROI PARAMETERS (Adjusted for Far-Right View) =====
ROI_X = 850       # Start ROI 800 px from left (shifting view to far right)
ROI_Y = 920       # Top of ROI 300 px down from top of the cropped image
ROI_W = 1300      # Width of the ROI (adjust as needed)
ROI_H = 130       # Height of the ROI (adjust as needed)

# Since we won't be resizing, the output video resolution will be the ROI size.
OUTPUT_RESOLUTION = (ROI_W, ROI_H)

# Reinitialize VideoWriter to use the ROI's native resolution.
out = cv2.VideoWriter(OUTPUT_VIDEO_PATH,
                      cv2.VideoWriter_fourcc(*'mp4v'),
                      fps, OUTPUT_RESOLUTION)

def process_video():
    """Processes and saves undistorted video by cropping out unwanted regions."""
    frame_count = 0
    start_time = time.time()

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # 1) Undistort with precomputed map
        undistorted_frame = cv2.remap(
            frame, map1, map2,
            interpolation=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT
        )

        # 2) Crop the black borders manually
        h, w = undistorted_frame.shape[:2]
        crop_x = int(w * 0.05)   # Remove 5% from left/right
        crop_y = int(h * 0.10)   # Remove 10% from top/bottom
        undistorted_cropped = undistorted_frame[crop_y:h-crop_y, crop_x:w-crop_x]

        # 3) Apply the ROI on the cropped image
        ch, cw = undistorted_cropped.shape[:2]
        # Clamp ROI coordinates so they don't exceed the image dimensions
        roi_x1 = max(0, min(ROI_X, cw - 1))
        roi_y1 = max(0, min(ROI_Y, ch - 1))
        roi_x2 = max(roi_x1, min(roi_x1 + ROI_W, cw))
        roi_y2 = max(roi_y1, min(roi_y1 + ROI_H, ch))

        runway_roi = undistorted_cropped[roi_y1:roi_y2, roi_x1:roi_x2]

        # 4) Instead of resizing, simply use the cropped ROI as the final frame
        final_frame = runway_roi

        # Write frame to output video
        out.write(final_frame)

        frame_count += 1
        elapsed_time = time.time() - start_time
        expected_time = frame_count * frame_interval

        # Sync processing speed to match FPS
        if expected_time > elapsed_time:
            time.sleep(expected_time - elapsed_time)

        if frame_count % 50 == 0:
            print(f" Processed {frame_count} frames...")

    cap.release()
    out.release()
    print(f" Undistorted and cropped video saved as '{OUTPUT_VIDEO_PATH}'")

# Run video processing in a separate thread to prevent freezing
processing_thread = threading.Thread(target=process_video)
processing_thread.start()
processing_thread.join()
