import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

# CONFIGURE THIS
GOOGLE_SHEET_ID = "1iDrg33Qkrhq8fmMZjc3rbaS9gXVnpfpE-5cP5bR1MyM"
SHEET_NAME = "Full_Listing"

def update_status_only(vault_no, date=None, status="Complete"):
    scope = ["https://spreadsheets.google.com/feeds",
             "https://www.googleapis.com/auth/spreadsheets",
             "https://www.googleapis.com/auth/drive.file",
             "https://www.googleapis.com/auth/drive"]

    creds = ServiceAccountCredentials.from_json_keyfile_name("google_credentials.json", scope)
    client = gspread.authorize(creds)

    sheet = client.open_by_key(GOOGLE_SHEET_ID).worksheet(SHEET_NAME)

    if date is None:
        date = datetime.now().strftime("%d%b%y")

    vault_id = str(vault_no)
    all_rows = sheet.get_all_values()

    for i, row in enumerate(all_rows):
        if len(row) >= 2 and row[0] == date and row[1] == vault_id:
            cell_row = i + 1  # gspread is 1-indexed
            sheet.update_cell(cell_row, 10, status)
            print(f"Updated status to '{status}' for {vault_id} on {date}")
            return

    print(f"Row not found for {vault_id} on {date}")

