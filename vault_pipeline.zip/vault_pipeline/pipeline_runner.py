import os
import time
import shutil
import subprocess
from vault_namer import get_next_vault_filenames
from update_google_sheet import update_status_only
from s3_upload import upload_to_s3

RAW_DIR = "raw"
PROCESSED_DIR = "processed"
RESULTS_DIR = "results"

def find_next_video():
    files = os.listdir(RAW_DIR)
    videos = [f for f in files if f.lower().endswith(".mp4")]
    return videos[0] if videos else None

def run_pipeline():
    while True:
        print("Checking for new videos...")
        filename = find_next_video()
        if not filename:
            time.sleep(5)
            continue

        print(f"New video detected: {filename}")

        video_name, csv_name, vault_no, date_str = get_next_vault_filenames()

        raw_path = os.path.join(RAW_DIR, filename)
        renamed_path = os.path.join(RAW_DIR, video_name)
        os.rename(raw_path, renamed_path)
        print(f"Renamed to: {video_name}")

        print("Running undistortion...")
        subprocess.run(["python3", "undistort_video.py", renamed_path], check=True)

        print("Running footfall + velocity analysis...")
        subprocess.run(["python3", "integrated_footfall_velocity.py"], check=True)

        # Move results
        final_csv = os.path.join(RESULTS_DIR, csv_name)
        shutil.move("final_output.csv", final_csv)
        final_vid = os.path.join(PROCESSED_DIR, video_name)
        shutil.move(renamed_path, final_vid)

        print("Uploading files to S3...")
        upload_to_s3(final_csv)
        upload_to_s3(final_vid)

        print("Updating Google Sheet...")
        update_status_only(vault_no=vault_no, date=date_str)

        print("Vault processed and logged.\n")
        time.sleep(2)

if __name__ == "__main__":
    os.makedirs(RAW_DIR, exist_ok=True)
    os.makedirs(PROCESSED_DIR, exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)
    run_pipeline()