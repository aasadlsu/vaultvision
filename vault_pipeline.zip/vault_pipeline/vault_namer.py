import os
import json
from datetime import datetime

CONFIG_PATH = "vault_config.json"

def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def save_config(config):
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)

def get_next_vault_filenames():
    today = datetime.now().strftime("%d%b%y")  # e.g. 08Apr25
    config = load_config()

    last_vault_num = config.get(today, 0)
    new_vault_num = last_vault_num + 1
    config[today] = new_vault_num
    save_config(config)

    video_filename = f"{today}_{new_vault_num}_DV.mp4"
    csv_filename = f"{today}_{new_vault_num}_DA.csv"
    return video_filename, csv_filename, new_vault_num, today

