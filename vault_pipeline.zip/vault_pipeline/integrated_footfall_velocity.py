import cv2
import csv
import math
from ultralytics import YOLO

FEET_MODEL_PATH = "best.pt"
VAULTER_MODEL_PATH = "yolov8n.pt"
VIDEO_PATH = "test_videos/undistorted_output.mp4"
OUTPUT_CSV = "final_output.csv"
meters_per_pixel = 0.00821
MAX_VELOCITY = 12.0

feet_model = YOLO(FEET_MODEL_PATH)
vaulter_model = YOLO(VAULTER_MODEL_PATH)

def detect_footfalls_from_y_velocity(foot_positions, fps, eps=3.0, n_consecutive=2):
    footfalls = []
    consecutive_low = 0
    for i in range(len(foot_positions) - 1):
        frame_idx, _, y_current = foot_positions[i]
        _, _, y_next = foot_positions[i + 1]
        dy = abs(y_next - y_current)
        if dy < eps:
            consecutive_low += 1
        else:
            consecutive_low = 0
        if consecutive_low >= n_consecutive:
            footfalls.append(foot_positions[i][0])
            consecutive_low = 0
    return footfalls

def process_video(video_path, output_csv):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return

    fps = cap.get(cv2.CAP_PROP_FPS)
    ret, first_frame = cap.read()
    if not ret:
        return

    ORIGIN = (0, first_frame.shape[0] // 2)
    foot_positions = []
    vaulter_x_by_frame = {}

    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    frame_idx = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        foot_results = feet_model(frame)
        for result in foot_results:
            for box in result.boxes:
                cls = int(box.cls[0])
                name = feet_model.names[cls]
                if name.lower() == "feet":
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    cx = (x1 + x2) // 2
                    cy = (y1 + y2) // 2
                    foot_positions.append((frame_idx, cx, cy))
                    break

        person_results = vaulter_model(frame)
        for result in person_results:
            for box in result.boxes:
                cls = int(box.cls[0])
                name = vaulter_model.names[cls]
                if name == "person":
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    center_x = (x1 + x2) // 2
                    vaulter_x_by_frame[frame_idx] = center_x
                    break

        frame_idx += 1

    cap.release()

    velocity_by_frame = {}
    sorted_frames = sorted(vaulter_x_by_frame.keys())
    for i in range(1, len(sorted_frames)):
        f1 = sorted_frames[i - 1]
        f2 = sorted_frames[i]
        dx = abs(vaulter_x_by_frame[f2] - vaulter_x_by_frame[f1])
        velocity = dx * meters_per_pixel * fps
        if velocity <= MAX_VELOCITY:
            velocity_by_frame[f2] = velocity

    footfall_frames = detect_footfalls_from_y_velocity(foot_positions, fps)

    with open(output_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Distance (m)", "Velocity (m/s)", "Footfall"])

        all_frames = sorted(set([fp[0] for fp in foot_positions] + list(vaulter_x_by_frame.keys())))
        foot_dict = dict((fp[0], (fp[1], fp[2])) for fp in foot_positions)

        for f_idx in all_frames:
            velocity = velocity_by_frame.get(f_idx)
            if velocity is None:
                velocity = velocity_by_frame.get(f_idx - 1) or velocity_by_frame.get(f_idx + 1)
            velocity_str = f"{velocity:.2f}" if velocity else ""

            is_footfall = "Footfall" if f_idx in footfall_frames else ""

            if f_idx in foot_dict:
                cx, cy = foot_dict[f_idx]
                dist_px = math.dist((cx, cy), ORIGIN)
            elif f_idx in vaulter_x_by_frame:
                cx = vaulter_x_by_frame[f_idx]
                dist_px = math.dist((cx, ORIGIN[1]), ORIGIN)
            else:
                dist_px = None

            distance_str = f"{dist_px * meters_per_pixel:.2f}" if dist_px is not None else ""
            writer.writerow([distance_str, velocity_str, is_footfall])

